package rest;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class ConfigReader {

        Properties prop;

    public ConfigReader() throws IOException {
        InputStream is = getClass()
                .getClassLoader()
                .getResourceAsStream("config.properties");

        prop = new Properties();
        prop.load(is);
    }

    public String getUsername() {
        return prop.getProperty("username");
    }

    public String getPassword() {
        return prop.getProperty("password");
    }

    public String getBaseUrl() {
        return prop.getProperty("baseUrl");

    }
     public String getBasePath() {
        return prop.getProperty("basePath");
    }
}


