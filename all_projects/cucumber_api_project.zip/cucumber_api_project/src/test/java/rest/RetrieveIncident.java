package rest;

import java.io.IOException;
import java.io.InputStream;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class RetrieveIncident {

    public static String sys_id="";


   @Test
    public void createIncident() throws IOException {

        ConfigReader config = new ConfigReader(); 

       InputStream is = getClass()
        .getClassLoader()
        .getResourceAsStream("createincident.json");

        String body = new String(is.readAllBytes());
        
            Response res = RestAssured
             .given()
            .baseUri(config.getBaseUrl())
            .basePath(config.getBasePath())
            .auth()
            .basic(config.getUsername(), config.getPassword())
            .header("Content-Type", "application/json")
            .body(body)
            
            .when()
            .post();
            
            int statusCode = res.getStatusCode();
            System.out.println("statusCode is: "+statusCode);

            sys_id=res.jsonPath().getString("result.sys_id");
            
           
        } 



    @Test(dependsOnMethods="createIncident")
    public void retrieveIncident() throws IOException {

        ConfigReader config = new ConfigReader(); 

        System.out.println(sys_id);
        
        Response res=RestAssured
        .given()
        .baseUri(config.getBaseUrl())
        .basePath(config.getBasePath() + "/{id}")
        .pathParam("id", sys_id )
        .auth()
        .basic(config.getUsername(), config.getPassword())
        
        .when()
        .get();

        
        System.out.println("The status code is: "+res.statusCode());
        
        
        
    }

}
