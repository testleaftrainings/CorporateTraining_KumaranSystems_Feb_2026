package rest;

import java.io.IOException;
import java.io.InputStream;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class UpdateIncident {

   public static String sys_id="";

    

    @Test
    public void createIncident() throws IOException {
        
        ConfigReader config = new ConfigReader();

       InputStream is = getClass()
        .getClassLoader()
        .getResourceAsStream("createincident.json");

        String body = new String(is.readAllBytes());
        
            Response res = RestAssured
             .given()
            .baseUri(config.getBaseUrl())
            .basePath(config.getBasePath())
            .auth()
            .basic(config.getUsername(), config.getPassword())
            .header("Content-Type", "application/json")
            .body(body)
            
            .when()
            .post();
            
            int statusCode = res.getStatusCode();
            System.out.println("statusCode is: "+statusCode);

            sys_id=res.jsonPath().getString("result.sys_id");
            
           
        } 


    @Test(dependsOnMethods="createIncident")
public void updateIncident() throws IOException {

    // Updated JSON (you can also read from file like create)

       ConfigReader config = new ConfigReader();
   
       InputStream is = getClass()
        .getClassLoader()
        .getResourceAsStream("updateincident.json");

        String updateBody = new String(is.readAllBytes());

    Response res = RestAssured
            .given()
            .baseUri(config.getBaseUrl())
            .basePath(config.getBasePath() + "/{id}")
            .pathParam("id", sys_id)
            .auth()
            .basic(config.getUsername(), config.getPassword())
            .header("Content-Type", "application/json")
            .body(updateBody)

            .when()
            .patch();   // or .put()

    int statusCode = res.getStatusCode();
    System.out.println("Update status code: " + statusCode);

    String updatedDesc = res.jsonPath().getString("result.short_description");
    System.out.println("Updated Short Description: " + updatedDesc);
}

}
