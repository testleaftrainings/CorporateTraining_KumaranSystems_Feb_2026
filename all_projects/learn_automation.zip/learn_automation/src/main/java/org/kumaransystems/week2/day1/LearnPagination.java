package org.kumaransystems.week2.day1;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

public class LearnPagination {

    public static void main(String[] args) throws InterruptedException {
       

        ChromeDriver driver = new ChromeDriver();
        driver.get("https://leafground.com/table.xhtml");

        boolean hasNextPage = true;

        while (hasNextPage) {

            // Get all rows
            List rows = driver.findElements(By.xpath("//tbody[@id='form:j_idt89_data']/tr"));

            for (int i = 1; i <= rows.size(); i++) {
                String name = driver.findElement(By.xpath("//tbody[@id='form:j_idt89_data']/tr[" + i + "]/td[1]")).getText();
                System.out.println(name);
            }

            // Check next button
            String nextClass = driver.findElement(By.xpath("//a[@class='ui-paginator-next']")).getAttribute("class");

            if (nextClass.contains("ui-state-disabled")) {
                hasNextPage = false; // last page reached
            } else {
                driver.findElement(By.xpath("//a[@class='ui-paginator-next']")).click();
                Thread.sleep(2000);
            }
        }

        driver.quit();
    }
    }


