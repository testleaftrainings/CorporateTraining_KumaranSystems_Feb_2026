package steps;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

public class login{

    
    public static ChromeDriver driver;


    
@Given("Enter the username")
public void enter_the_username() {
    // Write code here that turns the phrase above into concrete actions
   System.out.println("step1");
   driver=new ChromeDriver();
   driver.manage().window().maximize();
   driver.get("http://leaftaps.com/opentaps/control/main");
   driver.findElement(By.id("username")).sendKeys("DemoCSR2");

}
@Given("Enter the password")
public void enter_the_password() {
    // Write code here that turns the phrase above into concrete actions
    System.out.println("step 2");
    driver.findElement(By.id("password")).sendKeys("crmsfa");
}
@When("Click the login button")
public void click_the_login_button() {
    // Write code here that turns the phrase above into concrete actions
   System.out.println("step 3");
   driver.findElement(By.xpath("//input[@class='decorativeSubmit']")).click();
}
}


