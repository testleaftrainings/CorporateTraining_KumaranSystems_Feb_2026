Feature: login to leaftaps

Scenario: positive testcase
Given Enter the username
Given Enter the password
When Click the login button

