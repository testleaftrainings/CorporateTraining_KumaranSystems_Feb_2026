package utils;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcel {
                                   //EditLead
    public static String[][] readData(String filename) throws FileNotFoundException, IOException {
      //Setup the Path
      FileInputStream fis=new FileInputStream("Data/"+filename+".xlsx");
      
      //Locate the work
      XSSFWorkbook wb=new XSSFWorkbook(fis);

      //Locate worksheet
      XSSFSheet ws=wb.getSheetAt(0);

      //get the row count - With Header
       int rowCount=ws.getLastRowNum();
       System.out.println("rowCount is : "+rowCount);

       int physicalRowCount=ws.getPhysicalNumberOfRows();
       System.out.println("physicalRowCount is: "+physicalRowCount);

       //Count the column
       int columnCount=ws.getRow(0).getLastCellNum();
       System.out.println("columnCount is : "+columnCount);

       //retreive 1 value
       String row1Cell1Value=ws.getRow(1).getCell(1).getStringCellValue();
       System.out.println("row1Cell1Value is: "+row1Cell1Value);

       String[][] data=new String[rowCount][columnCount];

       for(int i=1;i<=rowCount;i++){
          for(int j=0;j<columnCount;j++){

          String allData=ws.getRow(i).getCell(j).getStringCellValue();
          data[i-1][j]=allData;
          //data[0][0]="TestLeaf";
          //data[0][1]="Hari";
          //Data[0][2]="R"

          //Data[1][0]="Qeagle"
          //Data[1][1]="Vinoth"
          //Data[2][2]="S"
          //System.out.println("allData is: "+allData);
          //String allData=ws.getRow(1).getCell(0).getStringCellValue();  //TestLeaf  data[0][0]
          //String allData=ws.getRow(1).getCell(1).getStringCellValue();   //Hari     data[0][1]
          //String allData=ws.getRow(1).getCell(2).getStringCellValue();  //R         data[0][2]

          //String allData=ws.getRow(2).getCell(0).getStringCellValue();  // Qeagle   data[1][0]
          //String allData=ws.getRow(2).getCell(1).getStringCellValue();  //Vinoth    data[1][1]
          //String allData=ws.getRow(2).getCell(2).getStringCellValue();   //S        data[1][2]
        }

     }

     return data;

      }

}
