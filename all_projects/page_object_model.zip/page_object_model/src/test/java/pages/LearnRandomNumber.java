package pages;

public class LearnRandomNumber {

    public static void main(String[] args) {
        int randomNumber = (int)(Math.random()*99999+9999);
        System.out.println(randomNumber);
    }

}
//0.4563925975834312        image123.png
//0.03970735108867518        image0.787625.png