package pages;



import java.io.IOException;

import org.openqa.selenium.By;

import base.BaseClass;

public class LoginPage extends BaseClass {
	

	public LoginPage enterUsername(String username) throws IOException {
		get().findElement(By.id("username")).sendKeys(username);

       reportStep("Pass", "Username entered successfully");
     
	   return this;
	}

	public LoginPage enterPassword(String password) {
		get().findElement(By.id("password")).sendKeys(password);
		return this;
	}

	public WelcomePage clickLoginButton() {
		get().findElement(By.className("decorativeSubmit")).click();
		//WelcomePage wp=new WelcomePage();
		//return wp;
		return new WelcomePage();
	}

}
