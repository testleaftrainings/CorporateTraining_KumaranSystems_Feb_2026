package pages;



import org.openqa.selenium.By;

import base.BaseClass;

public class CreateLeadPage extends BaseClass {
	
	

	public CreateLeadPage enterCompanyname(String companyName) {
		get().findElement(By.id("createLeadForm_companyName")).sendKeys(companyName);
	    return this;
	}

	public CreateLeadPage enterFirstname(String firstName) {
		get().findElement(By.id("createLeadForm_firstName")).sendKeys(firstName);
		return this;
	}

	public CreateLeadPage enterLastname(String lastName) {
		get().findElement(By.id("createLeadForm_lastName")).sendKeys(lastName);
		return this;
	}

	public ViewLeadsPage clickCreateLeadButton() {
		get().findElement(By.name("submitButton")).click();
		return new ViewLeadsPage();
	}

}
