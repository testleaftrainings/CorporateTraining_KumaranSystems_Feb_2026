package pages;

import base.BaseClass;

public class ViewLeadsPage extends BaseClass {
	
	
	
	public void verifyLead() {
		System.out.println("Lead is created");
		
}

}
