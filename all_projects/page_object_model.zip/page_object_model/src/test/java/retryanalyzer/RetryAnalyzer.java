package retryanalyzer;

import org.testng.IRetryAnalyzer;
import org.testng.ITestResult;

public class RetryAnalyzer implements IRetryAnalyzer {

  int count=0;
    public boolean retry(ITestResult result) {

        
        if(count<2){
            count++;      //count==2
            return true;  //retry=2
        }
        return false;
    }

}
