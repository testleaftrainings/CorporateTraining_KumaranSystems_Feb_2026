package base;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import utils.ReadExcel;



public class BaseClass {

	private static final ThreadLocal<ChromeDriver> driver=new ThreadLocal<ChromeDriver>();


public String testcaseName, testcaseDescription, testAuthor, testCategory;
    public static ExtentReports extent;
	public static ExtentTest test;
    public void set(){
		ChromeOptions opt=new ChromeOptions();
		opt.addArguments("guest");
      driver.set(new ChromeDriver(opt));
	}

	public ChromeDriver get(){
ChromeDriver value = driver.get();
return value;
	}


	
	//public static ChromeDriver driver;
	public String filename;
	@BeforeMethod
	public void preConditions() {
		set();
		
		
		
		get().manage().window().maximize();
		get().get("http://leaftaps.com/opentaps");

	}
	@AfterMethod
	public void postConditions() {
	get().close();

	}
@DataProvider(name="fetchData")
	public String[][] sendData() throws FileNotFoundException, IOException{
	return ReadExcel.readData(filename);
	}

@BeforeSuite
	public void startReport(){

     ExtentHtmlReporter reporter=new ExtentHtmlReporter("./reports/Leaftaps.html");

    extent=new ExtentReports();

     extent.attachReporter(reporter);


	}
    @AfterSuite
	public void stopReport(){
    extent.flush();
	}
   @BeforeClass
	public void testcaseDetails(){
		test = extent.createTest(testcaseName, testcaseDescription);
		test.assignAuthor(testAuthor);
		test.assignCategory(testCategory);
	}


   public void reportStep(String status, String message) throws IOException{

    if(status.equals("Pass")){
     test.pass(message,MediaEntityBuilder.createScreenCaptureFromPath(".././snaps/image"+takeSnap()+".png").build());
	}

    else{

	}


   }


   public int takeSnap() throws IOException{

     int randomNumber = (int)(Math.random()*99999+9999);

	        //Take Screenshot
         File sourceFile = get().getScreenshotAs(OutputType.FILE);
		//Assisgn Location
         File destinationFile=new File("./snaps/image"+randomNumber+".png");

		//Paste the screenshot in the Location
         FileUtils.copyFile(sourceFile, destinationFile);


		 return randomNumber;
   }


	

}
