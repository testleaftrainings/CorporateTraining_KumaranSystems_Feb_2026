package extentreport;


import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class LearnExtentReport {

    public static void main(String args[]) {
        
     //Empty page
     ExtentHtmlReporter reporter=new ExtentHtmlReporter("page_object_model/reports/Leaftaps.html");

     //Create a Test
     ExtentReports extent=new ExtentReports();

   //adding data to the html report
     extent.attachReporter(reporter);


    ExtentTest testcase = extent.createTest("Login function of Leaftaps", "Login function for Valid credentials");
    testcase.assignAuthor("Bharath");
    testcase.assignCategory("Sanity");
    
     //Close the report
     extent.flush();

    System.out.println("Report Generated");
   




    }

}
