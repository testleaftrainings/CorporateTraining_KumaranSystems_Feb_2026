Feature: Create Incident API

  Scenario: Create a new incident
    Given Set the base URI
    When Create a new incident request
    Then Validate status code is 201
