package steps;

import java.io.InputStream;

import static org.testng.Assert.assertEquals;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class CreateIncidentSteps {

    RequestSpecification request;
    Response response;
    

    @Given("Set the base URI")
    public void setBaseURI() throws Exception {

        InputStream is = getClass()
                .getClassLoader()
                .getResourceAsStream("createincident.json");

        

        request = RestAssured
                .given()
                .baseUri("https://dev314518.service-now.com")
                .basePath("/api/now/table/incident")
                .auth()
                .basic("admin","MQjN^vi%2e3A")
                .header("Content-Type", "application/json")
                .body(is);
    }

    @When("Create a new incident request")
    public void createIncident() {
        response = request
                .when()
                .post();
    }

    @Then("Validate status code is {int}")
    public void validateStatusCode(int statusCode) {
        assertEquals(response.getStatusCode(), statusCode);
    }
}
