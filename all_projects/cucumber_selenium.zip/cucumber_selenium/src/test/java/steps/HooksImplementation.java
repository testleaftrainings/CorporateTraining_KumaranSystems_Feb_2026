package steps;


import org.openqa.selenium.edge.EdgeDriver;

import io.cucumber.java.After;
import io.cucumber.java.Before;



public class HooksImplementation extends BaseClass {

@Before
public void preConditions(){
driver=new EdgeDriver();
driver.get("http://leaftaps.com/opentaps/control/main");
driver.manage().window().maximize();;
}

@After
public void postConditions(){
 driver.close();   
}
}
