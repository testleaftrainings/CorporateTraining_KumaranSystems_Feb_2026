package steps;

import org.openqa.selenium.By;

import org.openqa.selenium.edge.EdgeDriver;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class login extends BaseClass {


    @When("Enter the username as {string}")
     public void enterUsername(String username){
     driver.findElement(By.id("username")).sendKeys(username);   
    }
     
    @And("Enter the password as {string}")
     public void enterPassword(String password){
        driver.findElement(By.id("password")).sendKeys(password);
    }

     @And("Click on the Login button")
     public void clickLoginButton(){
        driver.findElement(By.className("decorativeSubmit")).click();
    }
     @Then("The user should be loggedin")
     public void verifyLogin(){
        System.out.println("Login successful");
    }

    
    @When("The user should not be loggedin")
   public void the_user_should_not_be_loggedin() {
        System.out.println("Login successful");
   }

}
