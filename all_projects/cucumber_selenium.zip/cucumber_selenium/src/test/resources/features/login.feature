Feature: Login module of Leaftaps application


@Sanity @Smoke
Scenario: Login with valid credentials

When Enter the username as 'Demosalesmanager'
And Enter the password as 'crmsfa'
And Click on the Login button
Then The user should be loggedin

@Smoke @Regression
Scenario: Login with invalid credentials

When Enter the username as 'Demo'
And Enter the password as 'crm'
And Click on the Login button
But The user should not be loggedin
