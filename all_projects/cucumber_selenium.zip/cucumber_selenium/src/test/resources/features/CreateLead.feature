Feature: CreateLead function of Leaftaps

@Regression @Smoke
Scenario Outline: CreateLead with multiple set of data

When Enter the username as 'Demosalesmanager'
And Enter the password as 'crmsfa'
And Click on the Login button
And Click on CRMSFA link
And Click on Leads link
And Click on CreateLead link
And Enter the companyname as <companyName>
And Enter the firstname as <firstName>
And Enter the lastname as <lastName>
And Click on the Createlead button
Then Lead should be created

Examples:
|companyName|firstName|lastName|
|'Kumaran'|'Vineeth'|'Rajendran'|
|'TestLeaf'|'Bhuvanesh'|'Moorthy'|
