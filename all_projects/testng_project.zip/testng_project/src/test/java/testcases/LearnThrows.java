package testcases;

import org.testng.annotations.Test;


public class LearnThrows {


     @Test
    public void assertMethod() throws InterruptedException,ArithmeticException {
       
    int age=-20;
    if(age>=18){
    System.out.println("Eligible for voting");
    }

    else{
      System.out.println("Not Eligible for voting");
    }

    if(age<=0){
      throw new ArithmeticException("Age is a Negative Value or Zero");
    }
 

   Thread.sleep(2000);


  }
}
  