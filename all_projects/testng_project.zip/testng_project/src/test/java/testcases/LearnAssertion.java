package testcases;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class LearnAssertion {

//Hard Assert -if failed, stops the execution

//Soft Assert -if failed, execution will not stop
@Test
    public void assertMethod() {
        ChromeOptions options=new ChromeOptions();
        options.addArguments("guest");
        //Launch the Browser
        ChromeDriver driver=new ChromeDriver(options);

        //Load the url  -get()
        driver.get("http://leaftaps.com/opentaps/control/main");

        //Maximiize the browser
        driver.manage().window().maximize();

        //add implicit wait
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));

        //locateElement - findElement
        //passing the value - sendKeys
        //Enter the username
        driver.findElement(By.id("username")).sendKeys("Demosalesmanager");


        //Enter Password
        driver.findElement(By.id("password")).sendKeys("crmsfa");

        //Click on the Login button
        WebElement clickButton=driver.findElement(By.className("decorativeSubmit"));

        clickButton.click();

        //Click on the CRMSFA link
        //driver.findElement(By.linkText("CRM/SFA")).click();
        driver.findElement(By.partialLinkText("M/SF")).click();

        //Clcik on Leads link
        driver.findElement(By.linkText("Leads")).click();

        //Click Create Lead
        driver.findElement(By.linkText("Create Lead")).click();

        //Enter the Companyname
        driver.findElement(By.id("createLeadForm_companyName")).sendKeys("Kumaran Systems");

        //Enter the firstname
        driver.findElement(By.id("createLeadForm_firstName")).sendKeys("Sakthi");

        //Enter the Lastname
        driver.findElement(By.id("createLeadForm_lastName")).sendKeys("S");

     //Select
     //Step1: Find the element
     WebElement sourceDD=driver.findElement(By.id("createLeadForm_dataSourceId"));

    //Create Object for Select Class
    Select opt=new Select(sourceDD);
     opt.selectByIndex(5);
     opt.selectByValue("LEAD_EMPLOYEE");

        //Click Create Lead button
        driver.findElement(By.name("submitButton")).click();

     
      //Find the Element of firstName
      String actualText=driver.findElement(By.id("viewLead_firstName_sp")).getText();
      String expetedText="sakthi";

      //Assert.assertEquals(actualText, expetedText);


    SoftAssert sa=new SoftAssert();
     sa.assertEquals(actualText, expetedText);
        System.out.println("Validated");
     sa.assertAll();
    


    }


}
