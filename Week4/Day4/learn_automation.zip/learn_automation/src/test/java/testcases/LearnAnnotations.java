package testcases;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class LearnAnnotations {
   
   
  
@BeforeMethod
    public void beforeMethod(){
        System.out.println("This is Before Method");
    }
     @BeforeSuite
    public void beforeSuite(){
        System.out.println("This is Before Suite");
    }
    @Test
    public void testcase1(){
        System.out.println("This is Testcase1");
    }
      @BeforeClass
    public void beforeClass(){
        System.out.println("This is Before Class");
    }
    @BeforeTest
    public void beforeTest(){
        System.out.println("This is Before Test");
    }
    @Test
public void testcase2(){
        System.out.println("This is Testcase2");
    }

@AfterMethod
    public void afterMethod(){
        System.out.println("This is Afer Method");
    }
  
@AfterClass
    public void afterClass(){
        System.out.println("This is After Class");
    }
    @AfterSuite
    public void afterSuite(){
        System.out.println("This is After Suite");
    }
@AfterTest
    public void afterTest(){
        System.out.println("This is After Test");
    }

}
