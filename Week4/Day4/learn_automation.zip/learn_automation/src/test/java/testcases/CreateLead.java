package testcases;

import org.openqa.selenium.By;
import org.testng.annotations.Test;



public class CreateLead extends BaseClass {



 
@Test(dataProvider="fetchData")
	public void createLead(String companyName, String firstName, String lastName) {
		
		
		driver.findElement(By.linkText("Create Lead")).click();
		driver.findElement(By.id("createLeadForm_companyName")).sendKeys(companyName);
		driver.findElement(By.id("createLeadForm_firstName")).sendKeys(firstName);
		driver.findElement(By.id("createLeadForm_lastName")).sendKeys(lastName);
		driver.findElement(By.name("submitButton")).click();
		
}
}






