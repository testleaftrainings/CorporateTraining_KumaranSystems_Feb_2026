package org.kumaransystems.week2.day1;

public class LearnMethods1 {

   

    public void methodName(){
        System.out.println("MethodName");
    }
}
