package org.kumaransystems.week4;

// This class demonstrates that a final class cannot be extended.
// Removing the inheritance and not overriding the final method keeps
// the code compilable.
public class Learnfinal1 {

    public void learn(){
        // implementation or example code here
    }

}
