package org.kumaransystems.week2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import java.time.Duration;

public class Assessment {

        public static void main(String[] args) throws InterruptedException {
        
        WebDriver driver= new EdgeDriver();
        //ImplicitWait
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(50));

        //Account Creation
        driver.get("https://en-gb.facebook.com/");

        driver.manage().window().maximize();
        
        driver.findElement(By.linkText("Create new account")).click();

        //Adding Account Details
        //FirstName
        driver.findElement(By.xpath("//input[@type='text']")).sendKeys("Vignesh");

        //LastName
        driver.findElement(By.xpath("(//div[@class='x6s0dn4 x78zum5 x1qughib xh8yej3']/input)[2]")).sendKeys("M");

       //Mobilenumber
       driver.findElement(By.xpath("(//div[@class='x6s0dn4 x78zum5 x1qughib xh8yej3']/input)[3]")).sendKeys("9994872657");

       //Password
       driver.findElement(By.xpath("(//div[@class='x6s0dn4 x78zum5 x1qughib xh8yej3']/input)[4]")).sendKeys("vicky123");

       //Gender
       driver.findElement(By.xpath("(//div[contains(@class,'xwoeoq')])[4]")).click();
       driver.findElement(By.xpath("//div[contains(@class,'html-div')]//div[text()='Male']")).click();

       // Day of Birth
       //Day
       driver.findElement(By.xpath("(//div[contains(@class,'xwoeoq')])[1]")).click();
       driver.findElement(By.xpath("//div[contains(@class,'html-div')]//div[text()='24']")).click();

       //Month
       driver.findElement(By.xpath("(//div[contains(@class,'xwoeoq')])[2]")).click();
       driver.findElement(By.xpath("//div[contains(@class,'html-div')]//div[text()='October']")).click();
           
       //Year
        driver.findElement(By.xpath("(//div[contains(@class,'xwoeoq')])[3]")).click();
        driver.findElement(By.xpath("//div[contains(@class,'html-div')]//div[text()='2002']")).click();

       Thread.sleep(3000);
       driver.quit();
    }

}



