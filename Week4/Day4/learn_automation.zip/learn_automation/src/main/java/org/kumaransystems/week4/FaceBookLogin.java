package org.kumaransystems.week4;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

public class FaceBookLogin {

    public static void main(String[] args) {
         //Launch the browser
        ChromeDriver driver=new ChromeDriver();
        
        //Load the url
        driver.get("https://www.facebook.com/");
        
        //maximize the browser
        driver.manage().window().maximize();

        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

        driver.findElement(By.xpath("//span[text()='Create new account']")).click();
  
        driver.findElement(By.xpath("//label[text()='First name']/preceding-sibling::input")).sendKeys("vineeth@gmail.com");

        driver.findElement(By.xpath("//label[text()='Surname']/preceding-sibling::input")).sendKeys("Rajendran");
   
   
      driver.findElement(By.xpath("//span[text()='Select your gender']/parent::div")).click();

      driver.findElement(By.xpath("//div[text()='Female']")).click();
   
    }

}
