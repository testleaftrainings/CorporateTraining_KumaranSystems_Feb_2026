package org.kumaransystems.codereview;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class HandleException {

    public static void main(String[] args) {

         ChromeOptions options=new ChromeOptions();
        options.addArguments("guest");
        //Launch the Browser
        ChromeDriver driver=new ChromeDriver(options);

        //Load the url  -get()
        driver.get("http://leaftaps.com/opentaps/control/main");

        //Maximiize the browser
        driver.manage().window().maximize();

        //add implicit wait
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

        //locateElement - findElement
        //passing the value - sendKeys
        //Enter the username
        try {
           driver.findElement(By.id("user")).sendKeys("Demosalesmanager"); 
        } catch (Exception e) {
            System.out.println(e);
        }
        
        //Enter Password
        try {
           driver.findElement(By.id("password")).sendKeys("crmsfa"); 
        } catch (Exception e) {
        }
        

        //Click on the Login button
        WebElement clickButton=driver.findElement(By.className("decorativeSubmit"));

        clickButton.click();
    }

}
