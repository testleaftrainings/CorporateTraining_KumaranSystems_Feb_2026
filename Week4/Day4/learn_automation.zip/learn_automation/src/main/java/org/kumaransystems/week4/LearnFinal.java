package org.kumaransystems.week4;

public final class LearnFinal {




    public final void learn(){
        
    }


    public static void main(String[] args) {
       
    }

}
