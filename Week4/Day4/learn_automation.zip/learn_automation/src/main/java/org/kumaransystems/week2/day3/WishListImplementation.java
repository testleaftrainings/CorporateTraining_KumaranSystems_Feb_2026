package org.kumaransystems.week2.day3;

public class WishListImplementation implements WishList{
    
public void addToWishlist(){
System.out.println("Wishlist added");
}

public void showWishList(){
   System.out.println("showWishlist"); 
}

public static void main(String[] args) {
    WishListImplementation options=new WishListImplementation();
    options.addToWishlist();
    options.showWishList();
}

}
