package com.leaftaps.pages;

import com.framework.selenium.api.design.Locators;
import com.framework.testng.api.base.ProjectSpecificMethods;

public class LoginPage extends ProjectSpecificMethods {

	public LoginPage enterUsername(String uName) {

		
		
		//clearAndType(locateElement("username"), uName);
		
		clearAndType(locateElement(Locators.XPATH, "//input[@id='username']"), uName);
		
		return this;
	}

	public LoginPage enterPassword(String passWord) {

	
		//clearAndType(locateElement("password"),passWord);

      clearAndType(locateElement("password"), passWord);

		reportStep(passWord+" password is entered successfully", "pass");
		
		return this;

	}

	public void clickLogin() {

		click(locateElement("Login"));
		
	
		//reportStep("Login button is clicked successfully", "pass");
		

	}

}
