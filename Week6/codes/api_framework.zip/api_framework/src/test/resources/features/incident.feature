Feature: ServiceNow Incident API

Scenario: CRUD Incident

Given User setup ServiceNow API
When User creates incident
Then Validate status code 201

When User retrieves incident
Then Validate status code 200

When User updates incident
Then Validate status code 200

When User deletes incident
Then Validate status code 204
