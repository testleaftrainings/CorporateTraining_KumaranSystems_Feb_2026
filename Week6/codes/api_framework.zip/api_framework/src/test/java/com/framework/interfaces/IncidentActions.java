package com.framework.interfaces;

import io.restassured.response.Response;

public interface IncidentActions {
    void setup();
    void setRequestBody(String body);
    void createIncident();
    void getIncident(String sysId);
    void updateIncident(String sysId);
    void deleteIncident(String sysId);
    int getStatusCode();
    Response getResponse();
   
}
