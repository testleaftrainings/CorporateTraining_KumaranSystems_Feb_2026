package com.framework.steps;

import com.framework.implementation.IncidentActionsImpl;
import com.framework.interfaces.IncidentActions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class IncidentSteps {

    IncidentActions api = new IncidentActionsImpl();
    String sysId = "";

    

    @Given("User setup ServiceNow API")
    public void setup() {
        api.setup();
    }

    @When("User creates incident")
    public void create() {
        api.setRequestBody("{\"short_description\":\"Test Incident\"}");
        api.createIncident();
        
        int statusCode = api.getStatusCode();
        System.out.println("Create Incident Status Code: " + statusCode);
        
        if (statusCode == 201 || statusCode == 200) {
            sysId = api.getResponse().jsonPath().getString("result.sys_id");
            System.out.println("Incident created with sys_id: " + sysId);
        } else {
            throw new RuntimeException("Failed to create incident. Status Code: " + statusCode + 
                    ". Response: " + api.getResponse().getBody().asString());
        }
    }

    @When("User retrieves incident")
    public void get() {
        api.getIncident(sysId);
    }

    @When("User updates incident")
    public void update() {
        api.setRequestBody("{\"short_description\":\"Updated Incident\"}");
        api.updateIncident(sysId);
    }

    @When("User deletes incident")
    public void delete() {
        api.deleteIncident(sysId);
    }

    @Then("Validate status code {int}")
    public void validate(int code) {
        System.out.println(api.getStatusCode());
    }
}
