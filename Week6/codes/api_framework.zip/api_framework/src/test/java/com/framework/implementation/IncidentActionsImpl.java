package com.framework.implementation;

import com.framework.interfaces.IncidentActions;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class IncidentActionsImpl implements IncidentActions {

    RequestSpecification request;
    Response response;
    String baseURI = "https://dev341733.service-now.com/api/now/table/incident";

    public void setup() {
        RestAssured.baseURI = baseURI;
        request = RestAssured.given()
                .auth().preemptive().basic("admin", "am0U%-Ty4kWV")
                .header("Content-Type", "application/json");
    }

 
    public void setRequestBody(String body) {
        request.body(body);
    }

    public void createIncident() {
        response = request.post();
        printResponseDetails();
    }

    public void getIncident(String sysId) {
        response = request.get("/" + sysId);
        printResponseDetails();
    }

    public void updateIncident(String sysId) {
        response = request.put("/" + sysId);
        printResponseDetails();
    }

    public void deleteIncident(String sysId) {
        response = request.delete("/" + sysId);
        printResponseDetails();
    }

    public int getStatusCode() {
        return response.getStatusCode();
    }

    public Response getResponse() {
        return response;
    }

    private void printResponseDetails() {
        System.out.println("\n========== API Response Details ==========");
        System.out.println("Status Code: " + response.getStatusCode());
        System.out.println("Content-Type: " + response.getContentType());
        System.out.println("Response Body:\n" + response.getBody().asString());
        System.out.println("========== End Response ==========");
    }
}
