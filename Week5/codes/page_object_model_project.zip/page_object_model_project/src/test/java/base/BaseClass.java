package base;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import utils.ReadExcel;
public class BaseClass {

	private static final ThreadLocal<ChromeDriver> tlDriver = new ThreadLocal<ChromeDriver>();
	public static String fileName, testCategory,authorName,testName,testDescription;
	public static ExtentReports extent;
	public static ExtentTest test;


	public void setDriver(){
		ChromeOptions options=new ChromeOptions();
		options.addArguments("guest");
    tlDriver.set(new ChromeDriver(options));
	}

	public ChromeDriver getDriver(){
	return tlDriver.get();
	}
	
	public ChromeDriver driver;
	public String filename;
	@BeforeMethod
	public void preConditions() {
		setDriver();
		
		
		
		getDriver().manage().window().maximize();
		getDriver().get("http://leaftaps.com/opentaps");

	}
	@AfterMethod
	public void postConditions() {
	getDriver().close();

	}
@DataProvider(name="fetchData")
	public String[][] sendData() throws FileNotFoundException, IOException{
	return ReadExcel.readData(filename);
	}

	@BeforeSuite
	public void startReport() {
		//Step1: Setup the path
				ExtentHtmlReporter reporter=new ExtentHtmlReporter("./reports/result.html");

			    //Step2:Create object for ExtentReports
				extent=new ExtentReports();
				
				//Step3: attach the data with the file
				extent.attachReporter(reporter);
	}
	
	@BeforeClass
	public void testcaseDetails() {
     test = extent.createTest(testName, testDescription);		
      test.assignCategory(testCategory);
      test.assignAuthor(authorName);
	}
	
	public int takeSnap() throws IOException {
		int randomNumber=(int) (Math.random()*99999999+999999999);
		File source = getDriver().getScreenshotAs(OutputType.FILE);
		File dest=new File("./snaps/image"+randomNumber+".png");
        FileUtils.copyFile(source, dest);
        return randomNumber;
	}
	
	public void reportStep(String status, String msg) throws IOException {
		if (status.equalsIgnoreCase("pass")) {
			test.pass(msg, MediaEntityBuilder.createScreenCaptureFromPath(".././snaps/image"+takeSnap()+".png").build());
		}
		else if(status.equalsIgnoreCase("fail")) {
			test.fail(msg, MediaEntityBuilder.createScreenCaptureFromPath(".././snaps/image"+takeSnap()+".png").build());
		}
		
}
	@AfterSuite
	public void stopReport() {
		extent.flush();

	}

	

}
