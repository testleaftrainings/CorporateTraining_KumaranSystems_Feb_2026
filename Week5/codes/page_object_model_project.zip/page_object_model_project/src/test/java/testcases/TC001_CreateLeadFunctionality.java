package testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;

public class TC001_CreateLeadFunctionality extends BaseClass {
	
	@BeforeTest
	public void setValues(){
     filename="CreateLead";
	 testCategory="smoke";
		authorName="Vineeth";
		testName="CreateLead";
		testDescription="testDescription";

	}
	
	@Test(dataProvider="fetchData")
	public void createLead(String uName, String pWord, String companyName, String firstName, String lastName) throws IOException {
		LoginPage lp=new LoginPage();   //abcd
		lp.enterUsername(uName)
		.enterPassword(pWord)
		.clickLoginButton()
		.clickCrmsfaLink()
		.clickLeadsLink()
		.clickCreateLeadLink()
		.enterCompanyname(companyName)
		.enterFirstname(firstName)
		.enterLastname(lastName)
		.clickCreateLeadButton()
		.verifyLead();
		
		

	}

}
